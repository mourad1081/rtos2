#include <gmp.h>
#include <mpi.h>
#include <time.h>
#include <iostream>
#include <cstring>
#include <unistd.h>
#include "utils.h"

#define SHA1_BITS_LENGTH         160

#define TAG_ADD_COLLISION          1
#define TAG_STOP                   0
#define TAG_GIVE_FIRST_COLLISION  29
#define TAG_NOT_FOUND              5
#define TAG_FINISHED               3
#define BASE                       2

#define NB_SLAVES                 12
#define NB_MANAGERS                3
#define MAX_SIZE_LSB_BASE_60      27

using namespace std;

void master(int B, int LSB);

void slave(int B, int LSB);


int strToInt(char *c) {
    char *endPtr;
    int value = std::strtol(c, &endPtr, 10);
    if(endPtr == c)
        throw std::invalid_argument("INVALID_ARGUMENT");
    return value;
}


// ============================================================

int bufferSize = 0;

int main(int argc, char *argv[])
{
    int B = 16, LSB = 64;
    int id_process;

    bufferSize = LSB + 2*B + 1;

    if(argc >= 5) {
        B = strToInt(argv[2]);
        LSB = strToInt(argv[4]);
    }

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &id_process);

    switch (id_process) {
        case 0:  master(B, LSB); break;
        default: slave(B,  LSB); break;
    }

    MPI_Finalize();
    return 0;
}

void slave(int B, int LSB)
{
    int nb_process_finished = 0;
    // ========= Initialization... =========
    // Each slave has its own map.
    map<string, string> treeHashes;
    vector<string> messageSplited;
    bool prevenu = false;
    int nbProcess, idProcess, idManager, tag, dest, msgReceived;
    char  msgRecv[bufferSize];
    char tmp = '1';
    string hashed, LSBString, message;
    MPI_Status status;
    // x2 parce que 1 byte est codé sur 2 valeurs hexadécimales 00 -> FF
    string startGeneration = Utils::initializeHexString(2*B, 'F');
    string endGeneration;
    // Affecte a nbProcess le nombre de processus qui executent ce programme
    MPI_Comm_size(MPI_COMM_WORLD, &nbProcess);
    // Affecte a idProcess mon numero de processus
    MPI_Comm_rank(MPI_COMM_WORLD, &idProcess);
    mpz_t maxValue;          // valeur maximale
    mpz_t range;
    mpz_t nbProcess_gmp;
    mpz_t start;             // Point de départ de la génération.
    mpz_t end;               // Fin de la génération.
    mpz_t lsbBase60;
    mpz_init(maxValue);      // initialization of the variable maxValue
    mpz_init(nbProcess_gmp); // initialization of the variable nbProcess
    mpz_init(range);         // initialization of the variable range
    mpz_init(start);
    mpz_init(end);
    mpz_init(lsbBase60);
    // Assign the value of "exhaustiveString" to "maxValue" (base 16)
    mpz_set_str(maxValue, startGeneration.c_str(), 16);
    // for the range
    mpz_set_ui(nbProcess_gmp, 15);
    // Divide maxValue by nbProcess_gmp and assign it to range (and truncate)
    mpz_fdiv_q(range, maxValue, nbProcess_gmp);
    mpz_mul_ui(start, range,  idProcess-1);
    mpz_mul_ui(end,   range,    idProcess);

    if(idProcess != 15)
        mpz_sub_ui(end, end, 1);

    startGeneration =  mpz_get_str(NULL, 16, start);
    endGeneration   =  mpz_get_str(NULL, 16, end);
    for (auto & c: startGeneration)
        c = toupper(c); // since the incrementations are in uppercase, we upper.
    for (auto & c: endGeneration)
        c = toupper(c); // since the incrementations are in uppercase, we upper.

    // Dans le cas où startGeneration n'est pas représenté sur 2*B caractères
    // (ce qui peut arriver avec gmp),
    // on le préfice avec autant de 0 que nécessaire. Pareil pour endGeneration.
    startGeneration.insert(startGeneration.begin(), 2*B - startGeneration.size(), '0');
    endGeneration.insert(endGeneration.begin(),     2*B - endGeneration.size(),   '0');

    // =========== Generation... ===========
    cout << " => Process " << idProcess << " must generate in range ["
         << startGeneration << ", " << endGeneration
         << "]" << endl;
    while(startGeneration.compare(endGeneration) != 0) {
        usleep(100);
        // Generate hash of the input
        hashed = sha1(Utils::hexToString(startGeneration));
        // Get the LSB
        LSBString = (Utils::hexToBin(hashed).substr(SHA1_BITS_LENGTH - LSB));
        // Check if there is a collision on my map.
        if(treeHashes.find(LSBString) == treeHashes.end())
            // No, then add it
            treeHashes[LSBString] = startGeneration;
        else {
            // Yes, then send it to master
            message = LSBString + string("#") + startGeneration;
            MPI_Send(const_cast<char*>(message.c_str()), bufferSize,
                     MPI_CHAR, 0, TAG_ADD_COLLISION, MPI_COMM_WORLD);
        }
        // Check si master veut que je lui donne un mot :
        MPI_Iprobe(0, TAG_GIVE_FIRST_COLLISION, MPI_COMM_WORLD,
                   &msgReceived, &status);
        // Il veut
        if(msgReceived) {
            MPI_Recv(msgRecv, bufferSize, MPI_CHAR, 0,
                     TAG_GIVE_FIRST_COLLISION, MPI_COMM_WORLD, &status);
            messageSplited = Utils::split(string(msgRecv), '#');
            // Message = <LSB # word base 16>
            if(treeHashes.find(messageSplited[0]) == treeHashes.end()) {
                // Not found (it may occur since we empty the map each 10M word)
                MPI_Send(&tmp, 1, MPI_CHAR, 0, TAG_NOT_FOUND,  MPI_COMM_WORLD);
            } else {
                message = messageSplited[0] + string("#")
                        + treeHashes[messageSplited[0]];
                MPI_Send(const_cast<char*>(message.c_str()), bufferSize,
                          MPI_CHAR, 0, TAG_ADD_COLLISION,
                          MPI_COMM_WORLD);
            }
        }
        // Increment the hex value of the string
        Utils::incrementString(startGeneration);

        // To not saturate the RAM, I empty the map every 10 million words
        if(treeHashes.size() >= 10000000) {
            cout << "Process " << idProcess << " empties his map..." << endl;
            treeHashes.empty();
        }
    }
    MPI_Send(&tmp, 1, MPI_CHAR, 0, TAG_FINISHED, MPI_COMM_WORLD);
    while(true) {
        // Check si master veut que je lui donne un mot :
        MPI_Iprobe(MPI_ANY_SOURCE, TAG_GIVE_FIRST_COLLISION, MPI_COMM_WORLD,
                   &msgReceived, &status);
        // Il veut
        if(msgReceived) {
            MPI_Recv(msgRecv, bufferSize, MPI_CHAR, MPI_ANY_SOURCE,
                     TAG_GIVE_FIRST_COLLISION, MPI_COMM_WORLD, &status);
            messageSplited = Utils::split(string(msgRecv), '#');
            // Message = <LSB base 60 # word>
            if(treeHashes.find(messageSplited[0]) == treeHashes.end()) {
                // Not found (it may occur since we empty the map each 10M word)
                MPI_Send(&tmp, 1, MPI_CHAR, 0, TAG_NOT_FOUND,  MPI_COMM_WORLD);
            }
            else {
                message = messageSplited[0] + string("#")
                        + treeHashes[messageSplited[0]];
                MPI_Send(const_cast<char*>(message.c_str()), bufferSize,
                          MPI_CHAR, 0, TAG_ADD_COLLISION,
                          MPI_COMM_WORLD);
            }
        }
        usleep(100);
        // Check si master me dit qu'il a finit
        MPI_Iprobe(0, TAG_STOP, MPI_COMM_WORLD, &msgReceived, &status);
        if(msgReceived) {
            MPI_Recv(&tmp, 1, MPI_CHAR, MPI_ANY_SOURCE, TAG_STOP, MPI_COMM_WORLD, &status);
            break;
        }
    }

}

void master(int B, int LSB)
{
    double end, start = MPI_Wtime();
    double restartTimeout = 0, timeout = 0;
    int nbProcess, nbProcessFinished = 0;
    map<string, std::ofstream> collisionFiles;
    vector<string> msgSplited;
    char message[bufferSize];
    int flag;
    char buff = '0';
    MPI_Status status;
    MPI_Comm_size(MPI_COMM_WORLD, &nbProcess);
    double timeExecutions[nbProcess];
    while((nbProcessFinished < nbProcess-1)
          || ( (nbProcessFinished == nbProcess-1) && timeout < 10))
    {
        // Check if someone send me a msg
        MPI_Iprobe(MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &flag, &status);
        if(flag)
        {
            if(status.MPI_TAG == TAG_ADD_COLLISION)
            {
                MPI_Recv(message, bufferSize, MPI_CHAR, MPI_ANY_SOURCE,
                         TAG_ADD_COLLISION, MPI_COMM_WORLD, &status);
                msgSplited = Utils::split(string(message), '#');
                // Has the file been created ?

                if(collisionFiles.find(msgSplited[0]) == collisionFiles.end())
                {
                    // Create it and inform the source that I also want the word
                    // with which there has been a collision
                    string name = "collisions_"
                                    + std::to_string(LSB) + "_bits_on_"
                                    + std::to_string(B)   + "_bytes_msg_"
                                    + msgSplited[0]       + ".csv";

                    collisionFiles[msgSplited[0]].open(name);
                    // Ask for the first collision
                    MPI_Send(message, bufferSize, MPI_CHAR, status.MPI_SOURCE,
                             TAG_GIVE_FIRST_COLLISION, MPI_COMM_WORLD);
                }
                string motHex = msgSplited[1];
                collisionFiles[msgSplited[0]]
                        << "\"0x"
                        << motHex << "\""
                        << ",\"0x" << sha1(Utils::hexToString(motHex))
                        << "\"" << endl;
                collisionFiles[msgSplited[0]].flush();

            }
            else if(status.MPI_TAG == TAG_FINISHED) {

                end = MPI_Wtime();
                timeExecutions[status.MPI_SOURCE] = (end - start);
                MPI_Recv(&buff, 1, MPI_CHAR, status.MPI_SOURCE, TAG_FINISHED,
                         MPI_COMM_WORLD, &status);
                nbProcessFinished++;
                if(nbProcessFinished == 15)
                    cout << "**** All slaves have finished their jobs. "
                            "Processing the pending request... \n10 seconds of "
                            "timeout between for each request....\n"
                            "If a timeout is exceeded, it means that there is no "
                            "more pennding request !"
                         << endl;
            }
            else if(status.MPI_TAG == TAG_NOT_FOUND) {
                MPI_Recv(&buff, 1, MPI_CHAR, status.MPI_SOURCE,
                         TAG_NOT_FOUND, MPI_COMM_WORLD, &status);
                // Do nothing
            }

            restartTimeout = MPI_Wtime();
        } else {
            timeout = MPI_Wtime() - restartTimeout;
        }
    }
    end = MPI_Wtime();
    // -10 Because there is 10 second of timeout
    timeExecutions[0] = (end - start) - 10;


    // write time
    std::ofstream times;
    times.open("time.txt");

    for(int i = 0; i < nbProcess; i++) {
        times << "Process " << i << " : " << timeExecutions[i] << " sec" << endl;
    }
    times.close();

    // kill all nodes
    for(int i = 1; i < nbProcess; i++)
        MPI_Send(&buff, 1, MPI_CHAR, i, TAG_STOP, MPI_COMM_WORLD);

    // close all files
    for(auto &e : collisionFiles) {
        e.second.close();
    }
    cout << "all files closed" << endl;
    cout << "MASTER FINISHED" << endl;
}
